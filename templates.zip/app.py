import pandas as pd
from flask import Flask, render_template, request, jsonify, redirect, url_for
import joblib
import os

app = Flask(__name__)

# Define the directory where the models are stored
MODEL_DIR = os.path.dirname(os.path.abspath(__file__))

# Define the path for the CSV file
PREDICTIONS_FILE = os.path.join(MODEL_DIR, 'predictions.csv')

# Define the features that the model was trained on
features = ['generation biomass', 'generation fossil brown coal/lignite', 'generation fossil gas',
            'generation solar', 'temp', 'humidity', 'pressure', 'total load actual', 'total load forecast']
target = 'price actual'


# 📌 Updated: This function now ensures the correct column order
def save_prediction(input_data, prediction, model_name):
    # Define the correct list of column names for the CSV file
    column_names = ['timestamp', 'model_name'] + features + ['prediction']

    # Prepare the data as a single dictionary
    data_to_save = {
        'timestamp': [pd.Timestamp.now()],
        'model_name': [model_name],
        **input_data,
        'prediction': [prediction]
    }

    new_df = pd.DataFrame(data_to_save)

    # Append to the CSV file
    header_needed = not os.path.exists(PREDICTIONS_FILE)
    new_df.to_csv(PREDICTIONS_FILE, mode='a', header=header_needed, index=False, columns=column_names)


# Load the scaler and models
try:
    scaler_path = os.path.join(MODEL_DIR, 'scaler.joblib')
    scaler = joblib.load(scaler_path)
    models = {}
    for filename in os.listdir(MODEL_DIR):
        if filename.endswith('_model.joblib'):
            model_name = filename.replace('_model.joblib', '').replace('linear_regression',
                                                                       'Linear Regression').replace('random_forest',
                                                                                                    'Random Forest').replace(
                'svr', 'SVR').replace('xgb', 'XGBoost').replace('nn', 'Neural Network')
            models[model_name] = joblib.load(os.path.join(MODEL_DIR, filename))
except FileNotFoundError:
    print("Error: One or more required files (scaler.joblib or model files) were not found.")
    exit()

if not models:
    print("No models were loaded. Please check your .joblib files.")
    exit()


@app.route('/')
def home():
    """الرابط الرئيسي لعرض صفحة إدخال البيانات."""
    return render_template('index.html', model_names=models.keys())


@app.route('/about')
def about():
    """الرابط لعرض صفحة 'عن المشروع'."""
    return render_template('about.html')


@app.route('/predict', methods=['POST'])
def predict():
    """الرابط لمعالجة بيانات الإدخال والتنبؤ بالسعر."""
    try:
        selected_model_name = request.form['model_name']
        model = models[selected_model_name]

        input_data = {feature: [float(request.form[feature])] for feature in features}

        input_df = pd.DataFrame(input_data, columns=features)
        scaled_input = scaler.transform(input_df)

        prediction = model.predict(scaled_input)[0]

        # 📌 Updated: Pass the model name to the save_prediction function
        save_prediction(input_data, prediction, selected_model_name)

        return render_template('result.html', prediction=f'{prediction:.2f}', model_name=selected_model_name)
    except Exception as e:
        return render_template('error.html', error=str(e))


@app.route('/history')
def history():
    if os.path.exists(PREDICTIONS_FILE):
        df = pd.read_csv(PREDICTIONS_FILE)
        predictions = df.to_dict('records')
    else:
        predictions = []

    return render_template('history.html', predictions=predictions)


@app.route('/delete/<int:index>', methods=['POST'])
def delete(index):
    if os.path.exists(PREDICTIONS_FILE):
        df = pd.read_csv(PREDICTIONS_FILE)

        if 0 <= index < len(df):
            df = df.drop(index).reset_index(drop=True)
            df.to_csv(PREDICTIONS_FILE, index=False)

    return redirect(url_for('history'))


@app.route('/training_results')
def training_results():
    results = [
        {'name': 'Linear Regression', 'mse': 139.347, 'r2': 0.300},
        {'name': 'Random Forest', 'mse': 48.963, 'r2': 0.754},
        {'name': 'SVR', 'mse': 103.090, 'r2': 0.482},
        {'name': 'XGBoost', 'mse': 75.368, 'r2': 0.621},
        {'name': 'Neural Network', 'mse': 88.155, 'r2': 0.557}
    ]
    best_model_name = "Random Forest"
    return render_template('training_results.html', results=results, best_model_name=best_model_name)


if __name__ == '__main__':
    app.run(debug=True)